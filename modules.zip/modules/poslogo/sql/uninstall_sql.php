<?php
$sql = array();
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_logo`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_logo_shop`';
