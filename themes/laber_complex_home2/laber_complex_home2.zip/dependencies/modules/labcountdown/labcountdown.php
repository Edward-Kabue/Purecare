<?php
/**
 */
if (!defined('_PS_VERSION_'))
    exit;
class labcountdown extends Module
{
    public function __construct()
    {
        $this->name = 'labcountdown';
        $this->version = '1.7.x';
        $this->author = 'labersthemes';
        $this->tab = 'front_office_features';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = array('min' => '1.5', 'max' => _PS_VERSION_);
        parent::__construct();
        $this->displayName = $this->l('LABER Countdown time price ');
        $this->description = $this->l('Module config time countdown price');
        $this->_searched_email = null;
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }

    public function install()
    {
        if (!parent::install() ||
            !$this->registerHook('displayHeader') ||
            !$this->registerHook('displayTimecountdown') ||
            !$this->registerHook('displayProductTab')||
            !$this->registerHook('displayFooterProduct')

        ){
            return false;
        }
        return true;
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    public function hookdisplayHeader($params)
    {

        $this->context->controller->addJS($this->_path . 'js/jquery.plugin.js', 'all');
         $this->context->controller->addJS($this->_path . 'js/jquery.countdown.js', 'all');
        $this->context->controller->addCSS($this->_path . 'css/jquery.countdown.css', 'all');
    }




    public function hookdisplayTimecountdown($params)
    {

        $product= $params['product'];
        if(isset($product->specificPrice)){
            $id_product = (int)$product->specificPrice['id_product'];
            $id_cate = (int)$product->id_category_default;
            $enddate =  (int)strtotime($product->specificPrice['to']);
            $this->context->smarty->assign(array(
                'idproduct' => $id_product,
                'enddate' => $enddate,
                'id_cate'=>$id_cate,
            ));
        }
        else {
            if(isset($params['product']['specific_prices'])){

                $id_product = (int)$params['product']['id_product'];
                $id_cate = (int)$params['product']['id_category_default'];
                if(isset($params['productCate'])){
                    $id_cate =   $params['productCate']['id'];
                    $this->context->smarty->assign('id_cate',$id_cate);
                }
                $enddate =  $params['product']['specific_prices']['to'];

                $time=strtotime($enddate);
                $month=date("m",$time);
                $year=date("Y",$time);
                $date=date("d",$time);
                $this->context->smarty->assign(array(
                    'idproduct' => $id_product,
                    'enddate' => $enddate,
                    'id_cate'=>$id_cate,
                ));
            }
        }
        return $this->display(__FILE__,'countdown.tpl');
    }


}