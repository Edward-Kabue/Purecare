# Add the banners with the information specified by the user.

