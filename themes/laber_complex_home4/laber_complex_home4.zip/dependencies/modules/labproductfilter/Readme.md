# Show product filter in hook

